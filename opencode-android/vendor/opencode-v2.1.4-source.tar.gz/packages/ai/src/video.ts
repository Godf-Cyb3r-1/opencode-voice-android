import { Effect, Schema, Stream } from "effect"
import { Generation, ProgressEvent, QueuedEvent, type AwaitOptions } from "./generation.js"
import { Media } from "./media.js"
import { MediaModel, composeRoute, tryRequest } from "./media-model.js"
import { MediaRoute } from "./route/media.js"
import { AIError, HttpOptions, MediaUsage, ProviderMetadata, ProviderOptions, type OpenString } from "./schema/index.js"
import { VideoClient, Service } from "./video-client.js"

// ---------------------------------------------------------------------------
// Model
// ---------------------------------------------------------------------------

export type VideoOptions = MediaModel.Options

export type VideoRoute = MediaRoute.AnyRoute<VideoRequestFor, VideoEvent, VideoResponse>

export class VideoModel<Options extends VideoOptions = VideoOptions> extends MediaModel<VideoRoute, Options> {
  declare protected readonly _VideoModel: void

  /** The number of type arguments selects the kind: `<Options>`, `<Options, Frame, State>`, or `<Options, Token>`. */
  static fromRoute<Options extends VideoOptions>(
    route: MediaModel.InlineRouteInput<VideoRequestFor<Options>, VideoResponse>,
    input: MediaRoute.ModelInput,
  ): VideoModel<Options>
  static fromRoute<Options extends VideoOptions, Frame, State>(
    route: MediaModel.StreamRouteInput<VideoRequestFor<Options>, VideoEvent, Frame, State>,
    input: MediaRoute.ModelInput,
  ): VideoModel<Options>
  static fromRoute<Options extends VideoOptions, Token>(
    route: MediaModel.QueuedRouteInput<VideoRequestFor<Options>, VideoResponse, Token>,
    input: MediaRoute.ModelInput,
  ): VideoModel<Options>
  static fromRoute<Options extends VideoOptions, Frame, State, Token>(
    route: MediaModel.AnyRouteInput<VideoRequestFor<Options>, VideoEvent, VideoResponse, Frame, State, Token>,
    input: MediaRoute.ModelInput,
  ) {
    return new VideoModel<Options>({
      id: input.id,
      provider: route.protocol.provider,
      http: input.http,
      route: composeRoute(route, input, collectResponse) as VideoRoute,
    })
  }
}

export const VideoModelSchema = Schema.declare((value): value is VideoModel => value instanceof VideoModel, {
  expected: "Video.Model",
})

// ---------------------------------------------------------------------------
// Request
// ---------------------------------------------------------------------------

export type VideoAspectRatio = Media.AspectRatio
export const VideoAspectRatio = Media.AspectRatio

export type VideoResolution = OpenString<"480p" | "720p" | "1080p" | "4k">

/** Pinned frames. Routes that accept only a first frame fail typed when `last` is present. */
export const VideoFrames = Schema.Struct({
  first: Schema.optional(Media.AssetSchema),
  last: Schema.optional(Media.AssetSchema),
}).annotate({ identifier: "Video.Frames" })
export type VideoFrames = Schema.Schema.Type<typeof VideoFrames>

export class VideoRequest extends Schema.Class<VideoRequest>("Video.Request")({
  model: VideoModelSchema,
  prompt: Schema.String,
  frames: Schema.optional(VideoFrames),
  /** Style or subject references that guide the output without pinning a frame. */
  references: Schema.optional(Schema.Array(Media.AssetSchema)),
  /** Source video for edit or extension routes. */
  video: Schema.optional(Media.AssetSchema),
  durationSeconds: Schema.optional(Schema.Number),
  aspect: Schema.optional(VideoAspectRatio),
  resolution: Schema.optional(Schema.String),
  /** Whether to generate an audio track; routes whose audio is always on fail typed on `false`. */
  audio: Schema.optional(Schema.Boolean),
  n: Schema.optional(Schema.Int),
  seed: Schema.optional(Schema.Number),
  negativePrompt: Schema.optional(Schema.String),
  providerOptions: Schema.optional(ProviderOptions),
  http: Schema.optional(HttpOptions),
}) {
  declare protected readonly _VideoRequest: void
}

export type VideoRequestFor<Options extends VideoOptions = VideoOptions> = Omit<
  VideoRequest,
  "model" | "providerOptions"
> & {
  readonly model: VideoModel<Options>
  readonly providerOptions?: Options
}

export type VideoModelOptions<Model> = Model extends VideoModel<infer Options> ? Options : never

export type VideoRequestInput<Model extends VideoModel = VideoModel> = Omit<
  ConstructorParameters<typeof VideoRequest>[0],
  "model" | "providerOptions" | "http" | "resolution"
> & {
  readonly model: Model
  readonly resolution?: VideoResolution
  readonly providerOptions?: NoInfer<VideoModelOptions<Model>>
  readonly http?: HttpOptions.Input
}

// ---------------------------------------------------------------------------
// Response and events
// ---------------------------------------------------------------------------

export class VideoResponse extends Schema.Class<VideoResponse>("Video.Response")({
  videos: Schema.Array(Media.AssetSchema),
  usage: Schema.optional(MediaUsage),
  notices: Schema.optional(Schema.Array(Media.Notice)),
  providerMetadata: Schema.optional(ProviderMetadata),
}) {
  get video() {
    return this.videos[0]
  }
}

export const VideoOutputEvent = Schema.Struct({
  type: Schema.tag("video"),
  index: Schema.Number,
  video: Media.AssetSchema,
}).annotate({ identifier: "Video.Event.Video" })

export const VideoFinishEvent = Schema.Struct({
  type: Schema.tag("finish"),
  usage: Schema.optional(MediaUsage),
  notices: Schema.optional(Schema.Array(Media.Notice)),
  providerMetadata: Schema.optional(ProviderMetadata),
}).annotate({ identifier: "Video.Event.Finish" })

const videoEventTagged = Schema.Union([QueuedEvent, ProgressEvent, VideoOutputEvent, VideoFinishEvent]).pipe(
  Schema.toTaggedUnion("type"),
)
export const VideoEvent = Object.assign(videoEventTagged, {
  is: {
    generationQueued: videoEventTagged.guards["generation-queued"],
    generationProgress: videoEventTagged.guards["generation-progress"],
    video: videoEventTagged.guards.video,
    finish: videoEventTagged.guards.finish,
  },
})
export type VideoEvent = Schema.Schema.Type<typeof videoEventTagged>

const collectResponse = (events: ReadonlyArray<VideoEvent>): Effect.Effect<VideoResponse> => {
  const finish = events.find(VideoEvent.is.finish)
  // A streaming video protocol's `finish` emits the terminal event or fails, so a completed stream always has one.
  if (finish === undefined) return Effect.die(new Error("The video stream completed without a finish event"))
  return Effect.succeed(
    new VideoResponse({
      videos: events.filter(VideoEvent.is.video).map((event) => event.video),
      usage: finish.usage,
      notices: finish.notices,
      providerMetadata: finish.providerMetadata,
    }),
  )
}

// ---------------------------------------------------------------------------
// Request-shaped call API
// ---------------------------------------------------------------------------

export function request<const Model extends VideoModel>(
  input: VideoRequestInput<Model>,
): VideoRequestFor<VideoModelOptions<Model>>
export function request(input: VideoRequest): VideoRequest
export function request(input: VideoRequest | VideoRequestInput) {
  if (input instanceof VideoRequest) return input
  return new VideoRequest({
    ...input,
    http: HttpOptions.make(input.http),
  })
}

const requestEffect = (input: VideoRequest | VideoRequestInput) => tryRequest(() => request(input))

export function start<const Model extends VideoModel>(
  input: VideoRequest | VideoRequestInput<Model>,
): Effect.Effect<Generation<VideoResponse>, AIError, Service>
export function start(input: VideoRequest | VideoRequestInput) {
  return requestEffect(input).pipe(Effect.flatMap((request) => VideoClient.start(request)))
}

export function generate<const Model extends VideoModel>(
  input: VideoRequest | VideoRequestInput<Model>,
  options?: AwaitOptions,
): Effect.Effect<VideoResponse, AIError, Service>
export function generate(input: VideoRequest | VideoRequestInput, options?: AwaitOptions) {
  return requestEffect(input).pipe(Effect.flatMap((request) => VideoClient.generate(request, options)))
}

/** Rebuild a generation handle from a persisted `Generation.token`, refreshing its status once. */
export const resume = (model: VideoModel, token: unknown): Effect.Effect<Generation<VideoResponse>, AIError, Service> =>
  VideoClient.resume(model, token)

export function stream<const Model extends VideoModel>(
  input: VideoRequest | VideoRequestInput<Model>,
  options?: AwaitOptions,
): Stream.Stream<VideoEvent, AIError, Service>
export function stream(input: VideoRequest | VideoRequestInput, options?: AwaitOptions) {
  return Stream.unwrap(requestEffect(input).pipe(Effect.map((request) => VideoClient.stream(request, options))))
}

export const Video = {
  request,
  start,
  generate,
  resume,
  stream,
} as const
